import './App.css';
import Body from './Components/Body/Body';
import Footer from './Components/Footer/Footer';
import Header from './Components/Header/Header';
import HeaderCard from './Components/HeaderCard/HeaderCard';

function App() {
  return (
    <div className="App">
      {/*Header wrapper=> wraps the header of the web app in a container for styles */}
      <div className="header__wrapper">
        {/* Header of the component containing header buttons, displayed at the very top*/}
        <Header />

        {/* The welcome message */}
        <div className="welcome__message">
          <h2>Welcome to</h2>
          <h1>Educrates Resources</h1>
        </div>
        {/* Header Card having 3 images after the welcome message */}
        <HeaderCard />
      </div>

      {/* body of the entire app starting from the tab button */}
      <Body />

      {/* footer of the app, displayed at the very bottom */}
      <Footer />
    </div>
  );
}

export default App;
